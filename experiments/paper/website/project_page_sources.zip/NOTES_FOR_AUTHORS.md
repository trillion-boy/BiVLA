# Project page: notes for the authors (not part of the published page)

## What is here

- Upload only the contents of `site/` (or unzip `project_page.zip`). Nothing else in this folder (this file, `content/`, `data/`, `figs/`, `media/`, `walls/`) goes into the anonymised repository.
- `site/` is the complete static page: `index.html`, `assets/` (two videos, ten wall clips with posters, two CSV files, three figures), `figs/` (foveation example). No scripts, no external requests, no fonts loaded from the network. Copy the **contents of `site/`** to the root of the anonymised repository behind `https://anonymous.4open.science/w/icra-bot/` so that `index.html` sits at the root; the `/w/` link then renders it. Total size about 20 MB (videos 15 MB, wall clips 3 MB, figures 1 MB).
- `build.py`, `style.css`, `content/*.md`, `data/*.csv`, `figures.json`, `walls.json`, `figs/`, `media/`, `walls/` are the sources. `python3 build.py` regenerates `site/` (needs the `markdown` package). `README_EDITING.md` says which file holds which part of the page.
- `data/full_settings.csv` (308 rows) and `data/per_task.csv` (2,296 rows) are the machine-readable tables behind Sections 2.1 and 2.2, computed from the per-episode records (`results_corrected/**/episodes.jsonl` and `summary.json`); the `in_table` column comes from `paired_results_all.csv`. They carry no paths or names and are offered for download on the page. The raw `summary.json` / `episodes.jsonl` files must **not** be published as they are, because their `arguments`, `checkpoint_manifest`, `output_dir`, `slurm_job_id` and `qos` fields contain user names and cluster identifiers.

## Statements on the page that the authors should confirm before publishing

The final paper says the project page carries "checkpoints, GPU cards, software versions, trick presets, per-cell p-values, and implementation caveats". The page delivers all six. The items below go beyond what the paper states; each is true of the run records, and the question is only whether the authors want it public.

1. **GPU cards** (Section 1.3). The paper says "a system equipped with 4x RTX 5090 GPUs". Every run file that records a card lists an RTX 5090, except 86 of the 500 episodes of the SmolVLA depth-pruning cells at two layers (Long, Goal) and four layers (Long, Goal, Object), dated 6 and 7 September (RTX PRO 6000, RTX 6000 Ada, L40S, RTX A6000). The page states this in one sentence. Once those five cells are rerun on the RTX 5090, send the new files and the sentence goes away.
2. **Two implementations of SmolVLA** (Section 1.3). Table II prints latency for the SmolVLA reuse, fusion and depth cells; the page says those cells were completed with a re-implemented evaluator that is 2 to 7 percent faster per call and that their success is read through the paired test alone.
3. **SmolVLA depth-pruning layers** are fixed indices (30; 28, 30; 24, 26, 28, 30) without a Block Influence measurement. The page lists the layers in the table of Section 1.1 but no longer says they were fixed.
4. **CogACT ran two fusion settings, not three** (Section 1.2): task-aware reproduces motion-entropy because CogACT exposes no text-to-vision attention where fusion runs. The paper counts thirteen settings for every backbone.
5. **Inert cells** (Section 1.2): conservative-adaptive fusion reused no patch on SpatialVLA and UniVLA; ten UniVLA reuse cells fired no gate; CronusVLA's three fusion settings have identical outcomes and no recorded parameters; SmolVLA task-aware fusion reused a median of 3.5 to 5 tokens.
6. **Run-to-run drift** (Section 2.4): on four WidowX pairs 9 to 17 percent of zero-fire reuse episodes end differently from the original run; CogACT's two fusion runs agree on all 200 episodes, so the page calls it drift between runs rather than per-call randomness. **Benjamini-Hochberg** (Section 2.4): 16 of 22 drops pass, no gain passes. The final paper reads the p-values as descriptive and prints neither.
7. **Depth-pruning calibration** (Section 1.1): Block Influence is measured on the first policy call of the evaluation run (CronusVLA: a separate pass with seed 10000). The paper says "calibration data".
8. **Foveation ramp** (Section 1.1): the paper says tau reaches one at the image boundary; the code reaches one at the farthest corner. The page states the code behaviour.
9. **LIBERO wrist view**: whether it was foveated is not recorded and the page does not say. Add a sentence if you know.
10. **Software** (Section 1.3): transformers 4.47.0 and the SDPA/eager statements for CogACT, CronusVLA, MiniVLA and SpatialVLA come from the attention-backend note, not from the run records; SmolVLA's lerobot 0.4.4 and transformers 4.51.3 and UniVLA's SDPA are recorded. OpenVLA and UniVLA transformers versions and the torch version are not in the records; add them if known.
11. **Latency rounding** (Section 1.3): the page recomputes ms/step as pooled episode time over pooled steps; Tables I and II differ by up to 0.1 ms in some cells (CogACT WidowX original 141.5 on the page, 141.41 in Table I). The page says so.
12. **LIBERO task names** (Section 2.2) are the standard LIBERO instructions in benchmark order (task 0 to 9); four were checked against the rollout videos. Confirm the harness used the benchmark order.
13. **Fractal apple task** (Section 2.2): place apple in closed top drawer is 0 of 50 for every configuration of every backbone; the page says so.

## Things that were deliberately left out

- Absolute paths, user names, cluster job ids and internal note file names.
- Everything from the earlier three-backbone study, because its numbers do not match the final paper.
- Any claim that fusion accelerates anything (no cache-level reuse was measured).
- A separate Limitations list (removed at the first author's request; the caveats above remain where they arise in Sections 1.2, 1.3 and 2.4).

## Video badge caveat

Five of the 150 rollout clips used in the videos (three wall tiles and two paired clips, all CogACT WidowX) carry a SUCCESS/FAILURE badge that differs from the episode record, because the WidowX rollout videos are a re-run. The page says under the walls that three of the 42 WidowX tiles end differently from the recorded run.
